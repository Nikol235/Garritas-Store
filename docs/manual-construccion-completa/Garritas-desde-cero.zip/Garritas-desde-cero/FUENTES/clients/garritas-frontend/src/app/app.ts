import { RolesComponent } from "./features/admin/roles.component";
import { UsuariosRolesComponent } from "./features/admin/usuarios-roles.component";
import { PrestacionesComponent } from "./features/prestaciones/prestaciones.component";
import { LogisticaComponent } from "./features/logistica/logistica.component";
import { PlanesComponent } from "./features/planes/planes.component";
import { DomainApi, Sede, stateLabel } from "./core/domain-api";
import { SedesComponent } from "./features/sedes/sedes.component";
import { EspecialistasComponent } from "./features/bienestar/especialistas.component";
import { CuentaComponent } from "./features/cuenta/cuenta.component";
import { CitasComponent } from "./features/citas/citas.component";
import { EnviosComponent } from "./features/envios/envios.component";
import { PagosComponent } from "./features/pagos/pagos.component";
import { ProductosComponent } from "./features/admin/productos.component";
import { ClientesComponent } from "./features/admin/clientes.component";
import { Component, DestroyRef, inject, signal, effect } from "@angular/core";
import { CurrencyPipe, DatePipe } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { timer, EMPTY, exhaustMap, catchError } from "rxjs";
import { HttpErrorResponse } from "@angular/common/http";
import { Auth } from "./core/auth";
import { Api, Categoria, Producto, Venta, Pago, pending } from "./core/api";
import { CartStore } from "./features/cart/cart-store";
import { CartPanel } from "./features/cart/cart-panel";
import { ProductCatalog } from "./features/catalogo/product-catalog";

@Component({
  selector: "app-root",
  imports: [
    FormsModule,
    CurrencyPipe,
    DatePipe,
    CartPanel,
    ProductCatalog,
    PrestacionesComponent,
    LogisticaComponent,
    PlanesComponent,
    SedesComponent,
    EspecialistasComponent,
    CuentaComponent,
    CitasComponent,
    EnviosComponent,
    PagosComponent,
    ProductosComponent,
    ClientesComponent,
    RolesComponent,
    UsuariosRolesComponent,
  ],
  templateUrl: "./app.html",
})
export class App {
  readonly auth = inject(Auth);
  readonly cart = inject(CartStore);
  private readonly api = inject(Api);
  private readonly domain = inject(DomainApi);
  readonly label = stateLabel;
  shippingSaleId = 0;
  private readonly destroy = inject(DestroyRef);
  readonly productos = signal<Producto[]>([]);
  readonly categorias = signal<Categoria[]>([]);
  readonly ventas = signal<Venta[]>([]);
  readonly pagos = signal<Record<number, Pago>>({});
  readonly error = signal("");
  readonly notice = signal("");
  readonly busy = signal(false);
  readonly loading = signal(true);
  readonly view = signal(
    sessionStorage.getItem("garritas-view") ||
      (this.cart.count() > 0 ? "nueva-orden" : "catalogo"),
  );
  readonly pending = pending;
  nombre = "";
  descripcion = "";
  categoriaId: number | undefined;

  constructor() {
    if (
      !this.auth.admin() &&
      [
        "productos",
        "categorias",
        "clientes",
        "logistica",
        "roles",
        "usuarios-roles",
      ].includes(this.view())
    )
      this.view.set("catalogo");
    if (this.auth.admin()) {
      this.cart.clear();
      if (["nueva-orden", "carrito"].includes(this.view()))
        this.view.set("catalogo");
    }
    this.refreshCatalogo();
    this.refreshSedes();
    effect(() => sessionStorage.setItem("garritas-view", this.view()));
    if (this.auth.loggedIn()) this.refreshVentas();
    timer(3000, 3000)
      .pipe(
        exhaustMap(() => {
          if (
            !this.auth.loggedIn() ||
            !this.ventas().some((v) => pending(v.estado))
          )
            return EMPTY;
          return this.api.ventas().pipe(
            catchError((e) => {
              this.fail(e);
              return EMPTY;
            }),
          );
        }),
        takeUntilDestroyed(this.destroy),
      )
      .subscribe((ventas) => {
        this.ventas.set(ventas);
        if (!ventas.some((v) => pending(v.estado))) this.refreshCatalogo();
      });
  }

  refreshSedes() {
    this.domain.get<Sede[]>("/sedes").subscribe({
      next: (s) => this.cart.setSedes(s),
      error: (e) => this.fail(e),
    });
  }
  openPrestacion(event: { sedeId: number; prestacionId: number }) {
    if (this.auth.admin()) return;
    sessionStorage.setItem("garritas-cita-sede", String(event.sedeId));
    sessionStorage.setItem(
      "garritas-cita-prestacion",
      String(event.prestacionId),
    );
    this.view.set("citas");
    if (!this.auth.loggedIn()) this.auth.login();
  }
  openServicios(id: number) {
    sessionStorage.setItem("garritas-servicios-sede", String(id));
    this.view.set("prestaciones");
  }
  openCitas(id: number) {
    sessionStorage.setItem("garritas-profesional", String(id));
    sessionStorage.setItem("garritas-view", "citas");
    this.view.set("citas");
    if (!this.auth.loggedIn()) this.auth.login();
  }
  shipping(id: number) {
    this.shippingSaleId = id;
    this.view.set("envios");
  }
  refreshCatalogo() {
    this.loading.set(true);
    this.api.productos().subscribe({
      next: (p) => {
        this.productos.set(p);
        this.cart.reconcile(p);
        this.loading.set(false);
      },
      error: (e) => {
        this.loading.set(false);
        this.fail(e);
      },
    });
    this.api.categorias().subscribe({
      next: (c) => this.categorias.set(c),
      error: (e) => this.fail(e),
    });
  }
  refreshVentas() {
    this.api.ventas().subscribe({
      next: (v) => this.ventas.set(v),
      error: (e) => this.fail(e),
    });
  }
  add(producto: Producto) {
    if (this.busy() || this.auth.admin()) return;
    this.error.set("");
    if (this.cart.add(producto))
      this.notice.set(producto.nombre + " añadido al carrito.");
    else
      this.error.set(
        "Ya tienes en el carrito todas las unidades disponibles de este producto.",
      );
  }
  checkout() {
    if (this.busy() || this.auth.admin()) return;
    this.error.set("");
    if (!this.auth.loggedIn()) {
      this.auth.login();
      return;
    }
    if (!this.cart.valid()) {
      this.error.set(
        "Revisa los productos y las cantidades de tu carrito antes de confirmar.",
      );
      return;
    }
    this.busy.set(true);
    this.api
      .crearVenta(this.cart.payload(), this.cart.checkoutKey())
      .subscribe({
        next: (venta) => {
          this.busy.set(false);
          this.cart.clear();
          this.notice.set(
            "Pedido #" +
              venta.id +
              " registrado. Estamos verificando el inventario y el pago.",
          );
          this.view.set("pedidos");
          this.refreshVentas();
          this.refreshCatalogo();
        },
        error: (e) => {
          this.busy.set(false);
          this.fail(e);
          if (e.status === 409) {
            this.refreshCatalogo();
            this.refreshSedes();
            this.domain
              .get<import("./core/domain-api").Cobertura[]>("/coberturas")
              .subscribe({
                next: (c) =>
                  this.cart.coberturas.set(c.filter((x) => x.activo)),
                error: () => this.cart.coberturas.set([]),
              });
          }
        },
      });
  }
  consultarPago(id: number) {
    this.api.pago(id).subscribe({
      next: (p) => this.pagos.update((all) => ({ ...all, [id]: p })),
      error: (e) => this.fail(e),
    });
  }
  edit(c: Categoria) {
    this.categoriaId = c.id;
    this.nombre = c.nombre;
    this.descripcion = c.descripcion ?? "";
  }
  save() {
    this.api
      .guardarCategoria(
        { nombre: this.nombre, descripcion: this.descripcion },
        this.categoriaId,
      )
      .subscribe({
        next: () => {
          this.nombre = "";
          this.descripcion = "";
          this.categoriaId = undefined;
          this.refreshCatalogo();
        },
        error: (e) => this.fail(e),
      });
  }
  remove(c: Categoria) {
    if (confirm("¿Eliminar categoría " + c.nombre + "?"))
      this.api.borrarCategoria(c.id).subscribe({
        next: () => this.refreshCatalogo(),
        error: (e) => this.fail(e),
      });
  }
  private fail(e: HttpErrorResponse) {
    this.error.set(
      e.status === 401
        ? "La sesión expiró. Inicia sesión de nuevo."
        : e.status === 403
          ? "No tienes permiso para esta operación."
          : e.status === 0
            ? "No se pudo contactar al servidor. Tu carrito se conserva; puedes reintentar la compra sin duplicarla."
            : (e.error?.detail ??
              e.error?.message ??
              "No se pudo completar la operación. Inténtalo de nuevo."),
    );
  }
}
