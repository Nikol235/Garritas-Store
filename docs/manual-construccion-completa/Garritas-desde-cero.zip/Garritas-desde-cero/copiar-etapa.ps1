﻿param(
  [Parameter(Mandatory=$true)][ValidateRange(1,18)][int]$Etapa,
  [Parameter(Mandatory=$true)][string]$Destino
)
$ErrorActionPreference = 'Stop'
$base = $PSScriptRoot
$lista = Join-Path $base ('ETAPAS/{0:d2}.txt' -f $Etapa)
$rutas = @(Get-Content -Encoding UTF8 $lista | Where-Object { $_.Trim() })
$destinoCompleto = [IO.Path]::GetFullPath($Destino)
# Primero comprobar TODOS los conflictos; no copiar parcialmente una etapa.
foreach ($ruta in $rutas) {
  $fuente = Join-Path (Join-Path $base 'FUENTES') $ruta
  $salida = Join-Path $destinoCompleto $ruta
  if (Test-Path $salida) {
    if ((Get-FileHash $fuente -Algorithm SHA256).Hash -ne (Get-FileHash $salida -Algorithm SHA256).Hash) {
      throw "Se conserva tu trabajo: el archivo existente es distinto: $salida. Compara antes de continuar."
    }
  }
}
foreach ($ruta in $rutas) {
  $fuente = Join-Path (Join-Path $base 'FUENTES') $ruta
  $salida = Join-Path $destinoCompleto $ruta
  New-Item -ItemType Directory -Force (Split-Path $salida) | Out-Null
  if (!(Test-Path $salida)) { Copy-Item -LiteralPath $fuente -Destination $salida }
}
Write-Host "Etapa $Etapa preparada: $($rutas.Count) archivos. Lee sus fichas antes de seguir."
